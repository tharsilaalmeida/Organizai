package com.example.organizai.ui.navigation

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import com.example.organizai.ui.features.calendario.CalendarioScreen
import com.example.organizai.ui.features.materiais.MateriaisScreen
import com.example.organizai.ui.features.progresso.ProgressoScreen
import com.example.organizai.ui.features.tarefas.TarefasScreen

@Composable
fun NavGraph(navController: NavHostController) {
    NavHost(
        navController = navController,
        startDestination = NavTarget.Home.route
    ) {
        composable(NavTarget.Home.route) {
            Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Text(text = "Organizaí", style = MaterialTheme.typography.headlineLarge)
                    Spacer(modifier = Modifier.height(24.dp))
                    Button(onClick = { navController.navigate(NavTarget.Tarefas.route) }) {
                        Text("Ver Tarefas")
                    }
                    Button(onClick = { navController.navigate(NavTarget.Materiais.route) }) {
                        Text("Ver Materiais")
                    }
                    Button(onClick = { navController.navigate(NavTarget.Calendario.route) }) {
                        Text("Ver Calendário")
                    }
                    Button(onClick = { navController.navigate(NavTarget.Progresso.route) }) {
                        Text("Ver Progresso")
                    }
                }
            }
        }
        composable(NavTarget.Tarefas.route) { TarefasScreen() }
        composable(NavTarget.Materiais.route) { MateriaisScreen() }
        composable(NavTarget.Calendario.route) { CalendarioScreen() }
        composable(NavTarget.Progresso.route) { ProgressoScreen() }
    }
}