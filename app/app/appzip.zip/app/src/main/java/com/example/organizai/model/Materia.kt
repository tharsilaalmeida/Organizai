package com.example.organizai.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "materias")
data class Materia(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val nome: String,
    val cor: String? = null,
    val usuarioId: Long
)