package com.example.organizai.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "materiais")
data class MaterialEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,
    val nome: String,
    val quantidade: Int = 0
)