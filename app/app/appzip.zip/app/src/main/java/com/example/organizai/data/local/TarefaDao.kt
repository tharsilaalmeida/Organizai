package com.example.organizai.data.local

import androidx.room.*
import com.example.organizai.model.Tarefa
import kotlinx.coroutines.flow.Flow

@Dao
interface TarefaDao {
    @Insert
    suspend fun insert(tarefa: Tarefa): Long

    @Update
    suspend fun update(tarefa: Tarefa)

    @Delete
    suspend fun delete(tarefa: Tarefa)

    @Query("UPDATE tarefas SET concluida = :concluida WHERE id = :id")
    suspend fun marcarComoConcluida(id: Long, concluida: Boolean)

    @Query("SELECT * FROM tarefas WHERE usuarioId = :usuarioId")
    fun listarPorUsuario(usuarioId: Long): Flow<List<Tarefa>>

    @Query("SELECT * FROM tarefas WHERE usuarioId = :usuarioId AND dataEntrega BETWEEN :inicio AND :fim")
    fun listarPorIntervalo(usuarioId: Long, inicio: Long, fim: Long): Flow<List<Tarefa>>
}