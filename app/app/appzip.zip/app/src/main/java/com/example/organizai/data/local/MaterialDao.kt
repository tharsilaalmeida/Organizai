package com.example.organizai.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface MaterialDao {
    @Query("SELECT * FROM materiais")
    fun getAll(): Flow<List<MaterialEntity>>

    @Insert
    suspend fun insert(material: MaterialEntity)
}