package com.example.organizai.data.local

import androidx.room.*
import com.example.organizai.model.Progresso
import kotlinx.coroutines.flow.Flow

@Dao
interface ProgressoDao {
    @Insert
    suspend fun insert(progresso: Progresso): Long

    @Query("SELECT * FROM progressos WHERE usuarioId = :usuarioId")
    fun listarPorUsuario(usuarioId: Long): Flow<List<Progresso>>

    @Query("SELECT * FROM progressos WHERE materiaId = :materiaId")
    fun listarPorMateria(materiaId: Long): Flow<List<Progresso>>
}