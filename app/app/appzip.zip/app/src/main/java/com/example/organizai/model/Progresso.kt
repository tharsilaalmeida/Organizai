package com.example.organizai.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "progressos")
data class Progresso(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val data: Long,
    val tarefasConcluidas: Int,
    val tarefasTotais: Int,
    val materiaId: Long? = null,
    val usuarioId: Long
)