package com.example.organizai.ui.features.progresso

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
fun ProgressoScreen() {
    Box(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(text = "Progresso — Lavinya", style = MaterialTheme.typography.headlineMedium)
            Spacer(modifier = Modifier.height(24.dp))
            
            Card(modifier = Modifier.padding(16.dp)) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(text = "Tarefas Concluídas: 0")
                    Text(text = "Tarefas Pendentes: 0")
                    Spacer(modifier = Modifier.height(8.dp))
                    LinearProgressIndicator(progress = 0f, modifier = Modifier.fillMaxWidth())
                    Text(text = "Porcentagem: 0%")
                }
            }
        }
    }
}