package com.example.organizai.data.local

import androidx.room.*
import com.example.organizai.model.Materia
import kotlinx.coroutines.flow.Flow

@Dao
interface MateriaDao {
    @Insert
    suspend fun insert(materia: Materia): Long

    @Update
    suspend fun update(materia: Materia)

    @Delete
    suspend fun delete(materia: Materia)

    @Query("SELECT * FROM materias WHERE usuarioId = :usuarioId")
    fun listarPorUsuario(usuarioId: Long): Flow<List<Materia>>
}