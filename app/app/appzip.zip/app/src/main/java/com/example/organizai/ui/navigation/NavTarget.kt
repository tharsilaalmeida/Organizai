package com.example.organizai.ui.navigation

sealed class NavTarget(val route: String) {
    object Home : NavTarget("home")
    object Tarefas : NavTarget("tarefas")
    object Materiais : NavTarget("materiais")
    object Calendario : NavTarget("calendario")
    object Progresso : NavTarget("progresso")
}