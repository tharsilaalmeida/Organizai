package com.example.organizai.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "tarefas")
data class Tarefa(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val titulo: String,
    val descricao: String? = null,
    val dataEntrega: Long,
    val concluida: Boolean = false,
    val materiaId: Long,
    val usuarioId: Long
)