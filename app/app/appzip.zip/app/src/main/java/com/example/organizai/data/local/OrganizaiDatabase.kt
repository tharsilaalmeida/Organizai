package com.example.organizai.data.local

import androidx.room.Database
import androidx.room.RoomDatabase
import com.example.organizai.model.Materia
import com.example.organizai.model.Progresso
import com.example.organizai.model.Tarefa
import com.example.organizai.model.Usuario

@Database(
    entities = [
        Usuario::class,
        Materia::class,
        Tarefa::class,
        Progresso::class
    ],
    version = 1,
    exportSchema = false
)
abstract class OrganizaiDatabase : RoomDatabase() {
    abstract fun usuarioDao(): UsuarioDao
    abstract fun materiaDao(): MateriaDao
    abstract fun tarefaDao(): TarefaDao
    abstract fun progressoDao(): ProgressoDao
}